Set ComLabPath="C:\ClassicalFEA\ComLab"
setx CML_INSTALLDIR %ComLabPath%
setx CML_RCFILE %ComLabPath%\RC\NAST.RC
setx CML_RFDIR %ComLabPath%\RF