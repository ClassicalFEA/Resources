ComLab (Computational Mechanics Lab or CML), sometimes referred to as "Nast-Core", is a finite element solver derived from Nastran-95 and subsequently improved by Harry Schaeffer. It is stored at https://github.com/ClassicalFEA/ComLab

It is no longer being developed and no longer officially supported. Source code is not available.

The package contains the compiled files, install instructions, manual, improvements compared to Nastran-95, and agreements.

Installation Note: For the primary install process, Environment variables must be defined. The installation manual describes the process.

NOTE: The original Comlab produced a .out file instead of a .f06. This version produces a .f06 instead of a .out.