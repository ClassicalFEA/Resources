60
STATICS                             1
INERTIA RELIEF                      2
NORMAL  MODES                       3
DIFFERENSTIFFNESS                   4
BUCKLING                            5
PIECEWISLINEAR                      6
DCEIGS  COMPLEX EIGENVALUES         7
DFREQ   FREQUENCRESPONSE            8
DTRANS  TRANSIENRESPONSE            9
MCEIGS  COMPLEX EIGENVALUES         10
MFREQ   FREQUENCRESPONSE            11
MTRANS  TRANSIENRESPONSE            12
STEADY  STATE                       3
TRANSIEN                            9
MODES                               3
REALEIGSEIGENVAL                    3
MFLUTTERFLUTTERANALYSIS             10
MAERO   AEROELASRESPONSE            11
NORMALMOMODES   ANALYSIS            13
CYCSTATXCYCLIC  SYMMETRY            14
CYCMODESCYCLIC  SYMMETRY            15
AERO    AEROTHERMOELASTI            16
BLADE   CYCLIC  MODAL               9
DDA     DESIGN ANALYSIS             17
DFV     FORCED VIBRATION            18
MFV     FORCED VIBRATION            19
STATIC                              1
CREATE  PART                        501
IMPORT  PART                        502
IMPORT  INPUTT2                     503
COPY    PART                        504
COMB                                505
COMBINE REDUCE                      506
TRANROT                             507
EXPORT  PART                        509
EXPORT  OUTPUT2                     511
REDUCE  CMS                         512
REDUCE  GUYAN                       513
UPDATE  SOLPART                     514
SOLVE   STATIC                      601
SOLVE   INERTIA                     602
SOLVE   MODES                       603
SOLVE   DIFFSTIF                    604
SOLVE   BUCKLING                    605
SOLVE   PIECEWIS                    606
SOLVE   DCEIGS                      607
SOLVE   DFREQ                       608
SOLVE   DTRANS                      609
SOLVE   MCEIGS                      610
SOLVE   MFREQ                       611
SOLVE   MTRANS                      612
SOLVE   MODES  DIFF                 613
SOLVE   NON    LINEAR               614
SOLVE   SENSITI                     615
SOLVE   OPTIMIZ                     616
RECOVER ASSEMBLY                    700
RECOVER PART STATIC                 701
RECOVER PART MODES                  703
RECOVER PART MFREQ                  711
RECOVER PART MTRAN                  712