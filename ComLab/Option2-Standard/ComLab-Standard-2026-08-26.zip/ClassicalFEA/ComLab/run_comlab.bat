@echo off
REM =====================================================================
REM run_comlab.bat -- run ComLab without setting any
REM permanent (User/System) environment variables.
REM
REM HOW IT WORKS: %~dp0 expands to the full path of the directory this
REM .bat file lives in (with a trailing backslash), so the three
REM CML_* variables are set from that automatically -- no hard-coded
REM path, and no persistent (setx-based) environment variable is
REM created. They only exist for the lifetime of this script and the
REM comlab.exe process it launches as a child.
REM
REM SETUP: place this file directly in ComLab's install root -- the
REM same folder that directly contains bin\, rc\, rf\, and examples\
REM (i.e. NOT inside bin\). This matches wherever you unzipped the
REM ComLab package, whatever you named that folder or drive.
REM It may (or may be required - TBD) that the Comlab folder be present in "C:\ClassicalFEA\Comlab"
REM
REM USAGE:
REM   run_comlab.bat "C:\path\input.dat"
REM   run_comlab.bat input.dat (if located in the same directory as this batch file (probably).
REM   
REM To use as a batch file:
REM   call run_comlab.bat "C:\path\input1.dat"
REM   call run_comlab.bat "C:\path\input2.dat"
REM
REM Output files (.f06, .log, etc.) are written next to the input
REM file, exactly as with the normal (permanent-env-var) install.
REM =====================================================================
REM NOTE: This will also create the required C:\temp directory if it does not exist.
REM NOTE: In the event that batch file does not work, evaluate the nast.rc file to see if the set paths are correct.

set CML_INSTALLDIR=%~dp0
set CML_RCFILE=%~dp0RC\NAST.RC
set CML_RFDIR=%~dp0RF

if "%~1"=="" (
    echo Usage: run_comlab.bat ^<path-to-input.dat^>
    exit /b 1
)

if not exist "%~dp0bin\comlab.exe" (
    echo ERROR: comlab.exe not found at %~dp0bin\comlab.exe
    echo        Make sure this .bat file is in the ComLab install root
    echo        ^(the folder that directly contains bin\, rc\, rf\^).
    exit /b 1
)

if not exist "C:\temp" (
    mkdir "C:\temp"
)

"%~dp0bin\comlab" %1 %2 %3 %4 %5 %6
